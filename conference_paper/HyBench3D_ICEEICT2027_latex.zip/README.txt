HyBench3D - ICEEICT 2027 paper (IEEE conference format, A4, 6 pages)

Overleaf: New Project -> Upload Project -> select this zip. Compiler: pdfLaTeX. Main file: main.tex.

Local build:
  pdflatex main
  bibtex main
  pdflatex main
  pdflatex main

Contents
  main.tex          paper source (Fig. 1 is drawn with TikZ inside this file)
  references.bib    bibliography (only cited entries are printed)
  main.bbl          pre-built bibliography (lets it compile even without running bibtex)
  IEEEtran.cls/.bst IEEE template files, bundled so every machine uses the same version
  figures/          the three image figures used in the paper
